#ifndef RAND
#define RAND

float getRand(); 
float getRandInRange(float high, float low);

#endif